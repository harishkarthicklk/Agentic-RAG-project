evaluation_dataset = [

# RAG QUESTIONS

{
"question":"What is fault tolerance?",
"reference_answer":"Fault tolerance is the ability of a system to continue operating despite failures."
},

{
"question":"What is CAP theorem?",
"reference_answer":"CAP theorem states that a distributed system can provide at most two of consistency, availability, and partition tolerance."
},

{
"question":"Difference between monolith and microservices?",
"reference_answer":"Monolith is a single application while microservices are independently deployable services."
},

{
"question":"What is circuit breaker pattern?",
"reference_answer":"Circuit breaker prevents repeated calls to failing services."
},

{
"question":"What is Byzantine Fault Tolerance?",
"reference_answer":"BFT allows a system to tolerate malicious or faulty nodes."
},

{
"question":"Explain active redundancy.",
"reference_answer":"Active redundancy uses multiple active components simultaneously."
},

{
"question":"Explain passive redundancy.",
"reference_answer":"Passive redundancy uses standby components activated during failures."
},

{
"question":"What is partition tolerance?",
"reference_answer":"Partition tolerance means the system continues operating despite network partitions."
},

{
"question":"What are consensus algorithms?",
"reference_answer":"Consensus algorithms help distributed nodes agree on a common state."
},

{
"question":"What is a modular monolith?",
"reference_answer":"A modular monolith is a monolithic application organized into independent modules."
},

# DIRECT QUESTIONS

{
"question":"Who is Elon Musk?",
"reference_answer":"Elon Musk is an entrepreneur known for Tesla and SpaceX."
},

{
"question":"Capital of India?",
"reference_answer":"New Delhi."
},

{
"question":"Who is Virat Kohli?",
"reference_answer":"Virat Kohli is an Indian cricketer."
},

{
"question":"What is Machine Learning?",
"reference_answer":"Machine learning enables systems to learn from data."
},

{
"question":"What is Artificial Intelligence?",
"reference_answer":"AI is the simulation of human intelligence by machines."
},

{
"question":"What is Deep Learning?",
"reference_answer":"Deep learning is a subset of machine learning using neural networks."
},

{
"question":"What is blockchain?",
"reference_answer":"Blockchain is a distributed ledger technology."
},

{
"question":"What is cloud computing?",
"reference_answer":"Cloud computing provides computing resources over the internet."
},

{
"question":"What is data science?",
"reference_answer":"Data science extracts insights from data."
},

{
"question":"What is reinforcement learning?",
"reference_answer":"Reinforcement learning learns through rewards and penalties."
}
]