from langchain_ollama import ChatOllama


class JudgeLLM:

    def __init__(self):

        self.llm = ChatOllama(
            model="mistral",
            temperature=0
        )

    def get_model(self):

        return self.llm