import re

from src.evaluation.judge_llm import JudgeLLM


judge = JudgeLLM().get_model()


def extract_score(response_text):

    match = re.search(
        r"\d+",
        response_text
    )

    if match:
        return float(match.group())

    return 1.0


def correctness_evaluator(
    run,
    example
):

    question = example.inputs["question"]

    reference_answer = (
        example.outputs["reference_answer"]
    )

    generated_answer = (
        run.outputs["answer"]
    )

    prompt = f"""
You are an expert evaluator.

Question:
{question}

Reference Answer:
{reference_answer}

Generated Answer:
{generated_answer}

Evaluate how correct the generated answer is.

Scoring:

5 = Excellent match
4 = Mostly correct
3 = Partially correct
2 = Mostly incorrect
1 = Completely incorrect

Return ONLY the score.
"""

    response = judge.invoke(
        prompt
    )

    raw_score = extract_score(
        response.content.strip()
    )

    normalized_score = (
        raw_score / 5.0
    )

    return {
        "key": "correctness",
        "score": normalized_score
    }


def relevance_evaluator(
    run,
    example
):

    question = (
        example.inputs["question"]
    )

    generated_answer = (
        run.outputs["answer"]
    )

    prompt = f"""
Question:
{question}

Answer:
{generated_answer}

Rate the relevance.

Scoring:

5 = Highly relevant
4 = Relevant
3 = Moderately relevant
2 = Slightly relevant
1 = Not relevant

Return ONLY the score.
"""

    response = judge.invoke(
        prompt
    )

    raw_score = extract_score(
        response.content.strip()
    )

    normalized_score = (
        raw_score / 5.0
    )

    return {
        "key": "relevance",
        "score": normalized_score
    }


def helpfulness_evaluator(
    run,
    example
):

    generated_answer = (
        run.outputs["answer"]
    )

    prompt = f"""
Answer:
{generated_answer}

Rate the helpfulness.

Scoring:

5 = Very helpful
4 = Helpful
3 = Somewhat helpful
2 = Slightly helpful
1 = Not helpful

Return ONLY the score.
"""

    response = judge.invoke(
        prompt
    )

    raw_score = extract_score(
        response.content.strip()
    )

    normalized_score = (
        raw_score / 5.0
    )

    return {
        "key": "helpfulness",
        "score": normalized_score
    }