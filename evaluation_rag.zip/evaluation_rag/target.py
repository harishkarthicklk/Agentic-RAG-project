from src.app import AgenticRAGApp

app = AgenticRAGApp()


def target(inputs: dict) -> dict:

    question = inputs["question"]

    result = app.ask(question)

    return {
        "answer": result["answer"]
    }