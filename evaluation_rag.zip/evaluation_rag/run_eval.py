from langsmith import Client

from src.evaluation.target import target

from src.evaluation.evaluators import (
    correctness_evaluator,
    relevance_evaluator,
    helpfulness_evaluator
)

client = Client()

experiment_results = client.evaluate(
    target,
    data="agentic-rag-phase2",
    evaluators=[
        correctness_evaluator,
        relevance_evaluator,
        helpfulness_evaluator
    ],
    experiment_prefix="agentic-rag-local-judge"
)

print(
    experiment_results.to_pandas()
)