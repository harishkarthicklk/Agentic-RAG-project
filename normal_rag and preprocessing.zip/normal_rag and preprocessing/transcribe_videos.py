from pathlib import Path
import json
import whisper


class VideoTranscriber:

    def __init__(self, model_name="base"):
        self.model = whisper.load_model(model_name)

    def process_videos(
        self,
        video_root="videos",
        output_root="data/documents"
    ):

        video_root = Path(video_root)
        output_root = Path(output_root)

        output_root.mkdir(
            parents=True,
            exist_ok=True
        )

        video_extensions = {
            ".mp4",
            ".mkv",
            ".avi",
            ".mov"
        }

        total_documents = 0

        for topic_folder in video_root.iterdir():

            if not topic_folder.is_dir():
                continue

            topic = topic_folder.name

            for video_file in topic_folder.iterdir():

                if video_file.suffix.lower() not in video_extensions:
                    continue

                print(f"Processing: {video_file.name}")

                result = self.model.transcribe(
                    str(video_file),
                    verbose=False
                )

                document = {
                    "doc_id": video_file.stem.lower().replace(" ", "_"),
                    "title": video_file.stem,
                    "topic": topic,
                    "source": video_file.name,
                    "transcript": result["text"],
                    "segments": result["segments"]
                }

                output_file = (
                    output_root /
                    f"{video_file.stem}.json"
                )

                with open(
                    output_file,
                    "w",
                    encoding="utf-8"
                ) as f:

                    json.dump(
                        document,
                        f,
                        ensure_ascii=False,
                        indent=4
                    )

                total_documents += 1

        print(
            f"\nSuccessfully created "
            f"{total_documents} documents"
        )