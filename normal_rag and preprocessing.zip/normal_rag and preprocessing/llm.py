from langchain_ollama import ChatOllama


class LLMModel:

    def __init__(self):

        self.llm = ChatOllama(
            model="llama3"
        )

    def generate(
        self,
        prompt
    ):

        response = self.llm.invoke(
            prompt
        )

        return response.content