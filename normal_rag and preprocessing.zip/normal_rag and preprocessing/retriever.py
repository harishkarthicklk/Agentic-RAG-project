from pymongo import MongoClient


class Retriever:

    def __init__(
        self,
        collection,
        embedding_model
    ):
        self.collection = collection
        self.embedding_model = embedding_model

    def retrieve(
        self,
        query,
        k=5
    ):

        query_embedding = (
            self.embedding_model
            .embed_query(query)
        )

        pipeline = [
        {
            "$vectorSearch": {
                "index": "vector_index",
                "path": "embedding",
                "queryVector": query_embedding,
                "numCandidates": 100,
                "limit": k
            }
        },
        {
            "$project": {
                "_id": 0,
                "content": 1,
                "metadata": 1,
                "score": {
                    "$meta": "vectorSearchScore"
                }
            }
        }   
    ]

        return list(
            self.collection.aggregate(
                pipeline
            )
        )