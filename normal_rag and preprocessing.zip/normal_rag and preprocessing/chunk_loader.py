import json
from pathlib import Path

from langchain_core.documents import Document


class ChunkLoader:

    def load_chunks(
        self,
        folder="data/chunks"
    ):

        documents = []

        for file in Path(folder).glob("*.json"):

            with open(
                file,
                "r",
                encoding="utf-8"
            ) as f:

                chunk_data = json.load(f)

            for chunk in chunk_data:

                documents.append(
                    Document(
                        page_content=chunk["content"],
                        metadata=chunk["metadata"]
                    )
                )

        return documents