import json
from pathlib import Path

from langchain_core.documents import Document


class DocumentLoader:

    def load_documents(
        self,
        folder="data/documents"
    ):

        documents = []

        for file in Path(folder).glob("*.json"):

            with open(
                file,
                "r",
                encoding="utf-8"
            ) as f:

                data = json.load(f)

            doc = Document(
                page_content=data["transcript"],
                metadata={
                    "doc_id": data["doc_id"],
                    "title": data["title"],
                    "topic": data["topic"],
                    "source": data["source"]
                }
            )

            documents.append(doc)

        return documents