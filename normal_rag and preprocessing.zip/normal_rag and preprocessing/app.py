from src.agentic_rag.graph_builder import graph

from src.retriever import Retriever
from src.llm import LLMModel
from src.config.database import get_collection
from src.embeddings import EmbeddingModel


class AgenticRAGApp:

    def __init__(self):

        collection = get_collection()

        embedding_model = (
            EmbeddingModel()
            .get_model()
        )

        self.retriever = Retriever(
            collection=collection,
            embedding_model=embedding_model
        )

        self.llm = LLMModel()

        self.graph = graph

    def ask(
        self,
        question
    ):

        result = self.graph.invoke(
            {
                "question": question,
                "retriever": self.retriever,
                "llm": self.llm
            }
        )

        return result

    def answer(
        self,
        question
    ):

        result = self.ask(
            question
        )

        return result["answer"]