class PromptBuilder:

    @staticmethod
    def build(
        question,
        context
    ):

        return f"""
You are an expert distributed systems assistant.

Use ONLY the provided context.

If the answer is not in the context,
say:

"I could not find enough information in the knowledge base."

Context:
{context}

Question:
{question}

Answer:
"""