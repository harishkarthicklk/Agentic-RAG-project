from pymongo import MongoClient
from dotenv import load_dotenv
import os
import certifi

load_dotenv()

def get_collection():

    uri = os.getenv("MONGODB_URI")

    client = MongoClient(
        uri,
        tls=True,
        tlsCAFile=certifi.where(),
        serverSelectionTimeoutMS=10000
    )

    print(client.admin.command("ping"))

    db = client["rag_db"]

    return db["youtube_chunks"]