from src.retriever import Retriever
from src.llm import LLMModel
from src.prompt_builder import PromptBuilder


class RAGPipeline:

    def __init__(
        self,
        collection,
        embedding_model
    ):

        self.retriever = Retriever(
            collection=collection,
            embedding_model=embedding_model
        )

        self.llm = LLMModel()

    def answer_question(
        self,
        question,
        k=5
    ):

        retrieved_docs = self.retriever.retrieve(
            question,
            k
        )

        context = "\n\n".join(
            doc["content"]
            for doc in retrieved_docs
        )

        prompt = PromptBuilder.build(
            question,
            context
        )

        answer = self.llm.generate(
            prompt
        )

        return {
            "question": question,
            "answer": answer,
            "context": context,
            "documents": retrieved_docs
        }