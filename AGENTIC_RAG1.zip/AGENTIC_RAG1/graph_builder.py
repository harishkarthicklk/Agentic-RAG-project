from langgraph.graph import StateGraph

from src.agentic_rag.state import GraphState

from src.agentic_rag.nodes import (
    retrieve_node,
    grade_documents_node,
    rag_node,
    direct_llm_node,
    route_question
)

workflow = StateGraph(
    GraphState
)

workflow.add_node(
    "retrieve",
    retrieve_node
)

workflow.add_node(
    "grade",
    grade_documents_node
)

workflow.add_node(
    "rag",
    rag_node
)

workflow.add_node(
    "direct",
    direct_llm_node
)

workflow.set_entry_point(
    "retrieve"
)

workflow.add_edge(
    "retrieve",
    "grade"
)

workflow.add_conditional_edges(
    "grade",
    route_question,
    {
        "rag": "rag",
        "direct": "direct"
    }
)

graph = workflow.compile()