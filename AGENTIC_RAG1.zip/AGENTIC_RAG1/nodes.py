from src.prompt_builder import PromptBuilder


def retrieve_node(state):

    question = state["question"]

    retriever = state["retriever"]

    docs = retriever.retrieve(
        question,
        k=5
    )

    return {
        "documents": docs
    }


def grade_documents_node(state):

    docs = state["documents"]

    if len(docs) == 0:

        print("No documents retrieved")

        return {
            "route": "direct"
        }

    top_score = docs[0]["score"]

    print(
        f"Top similarity score: {top_score}"
    )

    if top_score >= 0.75:

        print("Routing to RAG")

        return {
            "route": "rag"
        }

    print("Routing to Direct LLM")

    return {
        "route": "direct"
    }


def rag_node(state):

    llm = state["llm"]

    context = "\n\n".join(
        doc["content"]
        for doc in state["documents"]
    )

    prompt = PromptBuilder.build(
        state["question"],
        context
    )

    answer = llm.generate(
        prompt
    )

    return {
        "answer": answer,
        "context": context
    }


def direct_llm_node(state):

    llm = state["llm"]

    answer = llm.generate(
        state["question"]
    )

    return {
        "answer": answer
    }


def route_question(state):

    return state["route"]