from typing import TypedDict, List


class GraphState(TypedDict, total=False):

    question: str

    documents: List

    context: str

    answer: str

    route: str

    retriever: object

    llm: object