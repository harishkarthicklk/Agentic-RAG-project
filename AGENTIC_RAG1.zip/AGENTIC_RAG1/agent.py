from src.retriever import Retriever
from src.llm import LLMModel


class AgentResources:

    def __init__(
        self,
        collection,
        embedding_model
    ):

        self.retriever = Retriever(
            collection,
            embedding_model
        )

        self.llm = LLMModel()