GRADE_PROMPT = """
Question:
{question}

Retrieved Context:
{context}

Determine whether the context contains enough
information to answer the question.

Respond with only:

yes

or

no
"""